import sqlite3

# Crear conexión
conn = sqlite3.connect('copa_america.db')
cursor = conn.cursor()

# Crear tabla para equipos
cursor.execute('''
    CREATE TABLE IF NOT EXISTS equipos (
        id INTEGER PRIMARY KEY,
        nombre TEXT
    )
''')

# Crear tabla para jugadores
cursor.execute('''
    CREATE TABLE IF NOT EXISTS jugadores (
        id INTEGER PRIMARY KEY,
        nombre TEXT,
        edad INTEGER,
        posicion TEXT,
        equipo_id INTEGER,
        FOREIGN KEY (equipo_id) REFERENCES equipos(id)
    )
''')

# Insertar datos de equipos
equipos_data = [
    ('Argentina',),
    ('Brasil',),
    ('Uruguay',),
    ('Colombia',),
    ('Chile',),
    ('panama',),
    ('mexico',),
    
]

cursor.executemany('INSERT INTO equipos (nombre) VALUES (?)', equipos_data)

# Insertar datos de jugadores
jugadores_data = [
    ('Lionel Messi', 34, 'Delantero', 1), # Argentina
    ('Sergio Agüero', 33, 'Delantero', 1),
    ('Neymar Jr', 30, 'Delantero', 2),  # Brasil
    ('Casemiro', 30, 'Centrocampista', 2),
    ('Luis Suárez', 35, 'Delantero', 3),   # Uruguay
    ('Edinson Cavani', 36, 'Delantero', 3),
    ('James Rodríguez', 30, 'Centrocampista', 4), #Colombia
    ('Davinson Sánchez', 25, 'Defensa', 4),
    ('Alexis Sánchez', 32, 'Delantero', 5),  #chile
    ('Arturo Vidal', 34, 'Centrocampista', 5),
    ('Renán Addles',32,'delantero centro', 6),# panama
    ('Iván Anderson',26,'lateral derecho', 6),
    ('Marel Ruíz',23,'medio centro', 7),  #mexico
    ('Erick Sánche',24,'medio cenro',7),
    ]
cursor.executemany('INSERT INTO jugadores (nombre, edad, posicion, equipo_id) VALUES (?, ?, ?, ?)', jugadores_data)

# Consultar datos de equipos
cursor.execute('SELECT * FROM equipos')
print("Equipos:")
print(cursor.fetchall())

# Consultar datos de jugadores
cursor.execute('SELECT * FROM jugadores')
print("\nJugadores:")
print(cursor.fetchall())

# Cerrar conexión
conn.commit()
conn.close()
