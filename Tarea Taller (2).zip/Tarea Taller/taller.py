# taller practico primer ejercicio notas
nota1 = float(input("ingrese la nota a calificar"))
nota2 = float(input("ingrese la nota a calificar"))
nota3 = float(input("ingrese la nota a calificar"))

peso1 = 0.20
peso2 = 0.35
peso3 = 0.45

# obtener el promedio de notas 
promedio = (nota1 * peso1) +(nota2 * peso2) + (nota3 * peso3)

# obtener el resultado final
print("promedio final del estudiante en la asignatura",promedio)