#segundo taller de grafica geometricas
base=3 # en cm
altura=4 # en cm

#calcular el are de triangulo rectangulo
area = (base* altura)/2

#obtener resultado final
print("resultado final de triangulo rectanguloes:",area, "cm^2")