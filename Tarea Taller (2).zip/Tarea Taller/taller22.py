# sendo ejercico de grafica geometrica con la hipotenusa
base=3 # en cm
hipotenusa=5 # en cm

#calcular el area del triangulo rectangulo
area = (base * hipotenusa)/2

#obtener el resultado final
print("ressultado final del triangulo rectangulo es:",area,"cm^2")