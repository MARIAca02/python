class Libro:
    def __init__(self, titulo, autor, genero, num_paginas):
        self. titulo = titulo
        self. autor = autor 
        self. genero = genero
        self.num_paginas=num_paginas
    def mostrar_info(self):
        print("titulo:",self.titulo)
        print("autor:",self.autor)
        print("genero:",self.genero)
        print("numero de paginas:",self.num_paginas)
        
        
        
class Libroprestado(Libro):
    def __init__(self, titulo, autor, genero, num_paginas, prestado_a):  
        super().__init__(titulo, autor, genero, num_paginas)
        self.prestado_a = prestado_a
    
    
    def mostrar_info(self):
        super().mostrar_info()    
    print("prestado a:", self.prestado_a)
# crear objetos de la clase del libro
libro1 = libro("el libro codino de vinci","Dan Brown","Misterio", 624)
libro2 = libro("cien años de soledad,","grabirel garcia marquez","realismo magico",432)

# mostrar informacion de los libros
print("informacion del libro 1:")
libro1.mostrar_info()
print("\ninformacion del libro 2:")
libro2.mostrar_info()
#crear objetos de la clase liro prestado
libro_prestadi1 =libroprestado("python crash couse","Eric Mathes","programacion",544,"juan perez")
libre_prestado2 = libroprestado("clean code","robertc.martin","prgramacion",464,"maria gomez")
#mostar informacion de los libros prestado
print("\ninfomacion del libro prestado 1:")
libro_prestadi1.mostrar_info()
print("\ninformacion del libro prestado 2:")
libro_prestado2.mostar_info()

