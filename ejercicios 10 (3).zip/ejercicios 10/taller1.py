# Solicitar la cantidad de metros al usuario
metros_usuario = float(input("Ingresa la cantidad de metros: "))

# Realizar la conversión
pies_resultado = metros_usuario = 3.28084
pulgadas_resultado= pies_resultado = 12

# Mostrar el resultado
print(f"{metros_usuario} metros son equivalentes a {pies_resultado:.2f} pies y {pulgadas_resultado:.2f} pulgadas.")