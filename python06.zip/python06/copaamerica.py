import sqlite3

# Crear conexión
conn = sqlite3.connect('copaamerica.db')
cursor = conn.cursor()

# Crear tabla
cursor.execute('''CREATE TABLE IF NOT EXISTS productos
               (id jugadores INTEGER PRIMARY KEY, equipo nombre TEXT, edad, posicion,jugadores suplente INTEGER)''')
conn.commit()

# Insertar datos
JUGADORES= [
    ('Argentina','julian alvarez',24,'delantero',),
    ('Bolivia', 50.0, 100),
    ('Brasil ', 70.0, 80),
    ('ChileC', 60.0, 120),
    ('Colombia ', 90.0, 60),
    ('Ecuador ', 55.0, 150)  
    ('Perú ', 70.0, 80),
    ('Paraguay ', 60.0, 120),
    ('Uruguay ', 90.0, 60),
    ('Venezuela ', 55.0, 150)  
    ('Estados Unidos ', 70.0, 80),
    ('Panamá ', 60.0, 120),
    ('México ', 90.0, 60),
    ('Jamaica ', 55.0, 150)    
]
cursor.executemany('INSERT INTO jugadores (equipo nombre, edad, posicion) VALUES (?,?,?)', jugadores)
conn.commit()

# Consultar datos
cursor.execute('SELECT * FROM jugadores WHERE edad > 24')
resultados = cursor.fetchall()
print("Productos con precios superiores a $50:")
for jugadores in resultados:
    print(jugadores)

# Actualizar datos
cursor.execute('UPDATE jugadores SET edad = 24 WHERE id = 24')
conn.commit()
print("edad actualizado para eljugadores julian alvarez")

# Eliminar datos
cursor.execute('DELETE FROM jugadores WHERE id = 24')
conn.commit()
print("jugadores julian alvarez eliminado de la base de datos jugadores")

# Cerrar conexión
conn.close()
