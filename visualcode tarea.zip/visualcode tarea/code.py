a=1
b=2
suma=(a+b)
print (suma)