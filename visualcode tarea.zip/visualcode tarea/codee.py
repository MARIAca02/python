b=3
h=4
multiplicar (b*h)
print (3*4)
